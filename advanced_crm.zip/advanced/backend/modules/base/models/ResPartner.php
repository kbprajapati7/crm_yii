<?php

namespace backend\modules\base\models;

use Yii;

/**
 * This is the model class for table "res_partner".
 *
 * @property integer $id
 * @property string $name
 * @property integer $company_id
 * @property string $image
 * @property integer $country_id
 * @property string $street
 * @property string $street2
 * @property string $city
 * @property integer $zip
 * @property string $email
 * @property string $is_company
 * @property string $customer
 * @property string $fax
 * @property string $employee
 * @property string $active
 * @property string $phone
 * @property string $mobile
 * @property string $dob
 * @property integer $state_id
 * @property integer $parent_id
 * @property integer $title
 *
 * @property ResCompany $company
 * @property ResCountry $country
 * @property ResCountryState $state
 */
class ResPartner extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'res_partner';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'company_id', 'image', 'country_id', 'street', 'street2', 'city', 'zip', 'email', 'is_company', 'customer', 'fax', 'employee', 'active', 'phone', 'mobile', 'dob', 'state_id', 'parent_id', 'title'], 'required'],
            [['company_id', 'country_id', 'zip', 'state_id', 'parent_id', 'title'], 'integer'],
            [['is_company', 'customer', 'employee', 'active'], 'string'],
            [['dob'], 'safe'],
            [['name', 'street', 'street2', 'city', 'email', 'fax'], 'string', 'max' => 64],
            [['image'], 'string', 'max' => 100],
            [['phone', 'mobile'], 'string', 'max' => 13]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'company_id' => 'Company ID',
            'image' => 'Image',
            'country_id' => 'Country ID',
            'street' => 'Street',
            'street2' => 'Street2',
            'city' => 'City',
            'zip' => 'Zip',
            'email' => 'Email',
            'is_company' => 'Is Company',
            'customer' => 'Customer',
            'fax' => 'Fax',
            'employee' => 'Employee',
            'active' => 'Active',
            'phone' => 'Phone',
            'mobile' => 'Mobile',
            'dob' => 'Dob',
            'state_id' => 'State ID',
            'parent_id' => 'Parent ID',
            'title' => 'Title',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCompany()
    {
        return $this->hasOne(ResCompany::className(), ['id' => 'company_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCountry()
    {
        return $this->hasOne(ResCountry::className(), ['id' => 'country_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getState()
    {
        return $this->hasOne(ResCountryState::className(), ['id' => 'state_id']);
    }
}
