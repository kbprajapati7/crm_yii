<?php

namespace backend\modules\base\models;

use Yii;

/**
 * This is the model class for table "res_country".
 *
 * @property integer $id
 * @property string $name
 * @property string $image
 * @property string $code
 * @property integer $currency_id
 *
 * @property ResCurrency $currency
 * @property ResCountryState[] $resCountryStates
 * @property ResPartner[] $resPartners
 */
class ResCountry extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'res_country';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'image', 'code', 'currency_id'], 'required'],
            [['currency_id'], 'integer'],
            [['name'], 'string', 'max' => 64],
            [['image'], 'string', 'max' => 100],
            [['code'], 'string', 'max' => 2],
            [['code'], 'unique']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'image' => 'Image',
            'code' => 'Code',
            'currency_id' => 'Currency ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCurrency()
    {
        return $this->hasOne(ResCurrency::className(), ['id' => 'currency_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getResCountryStates()
    {
        return $this->hasMany(ResCountryState::className(), ['country_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getResPartners()
    {
        return $this->hasMany(ResPartner::className(), ['country_id' => 'id']);
    }
}
