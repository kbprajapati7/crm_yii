<?php

namespace backend\modules\base\models;

use Yii;

/**
 * This is the model class for table "res_partner_title".
 *
 * @property integer $id
 * @property string $name
 * @property string $domain
 */
class ResPartnerTitle extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'res_partner_title';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'domain'], 'required'],
            [['name', 'domain'], 'string', 'max' => 64]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'domain' => 'Domain',
        ];
    }
}
