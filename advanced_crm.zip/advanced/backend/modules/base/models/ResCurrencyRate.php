<?php

namespace backend\modules\base\models;

use Yii;

/**
 * This is the model class for table "res_currency_rate".
 *
 * @property integer $id
 * @property string $name
 * @property integer $currency_id
 * @property double $currency_rate
 *
 * @property ResCurrency $currency
 */
class ResCurrencyRate extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'res_currency_rate';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'currency_id', 'currency_rate'], 'required'],
            [['currency_id'], 'integer'],
            [['currency_rate'], 'number'],
            [['name'], 'string', 'max' => 64]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'currency_id' => 'Currency ID',
            'currency_rate' => 'Currency Rate',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCurrency()
    {
        return $this->hasOne(ResCurrency::className(), ['id' => 'currency_id']);
    }
}
