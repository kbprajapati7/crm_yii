<?php

namespace backend\modules\base\models;

use Yii;

/**
 * This is the model class for table "res_country_state".
 *
 * @property integer $id
 * @property string $name
 * @property integer $country_id
 * @property string $code
 *
 * @property ResCountry $country
 * @property ResPartner[] $resPartners
 */
class ResCountryState extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'res_country_state';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'country_id', 'code'], 'required'],
            [['country_id'], 'integer'],
            [['name'], 'string', 'max' => 64],
            [['code'], 'string', 'max' => 2]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'country_id' => 'Country ID',
            'code' => 'Code',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCountry()
    {
        return $this->hasOne(ResCountry::className(), ['id' => 'country_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getResPartners()
    {
        return $this->hasMany(ResPartner::className(), ['state_id' => 'id']);
    }
}
