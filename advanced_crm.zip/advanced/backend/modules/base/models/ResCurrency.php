<?php

namespace backend\modules\base\models;

use Yii;

/**
 * This is the model class for table "res_currency".
 *
 * @property integer $id
 * @property string $name
 * @property string $active
 * @property double $roundingFactor
 * @property string $symbol
 *
 * @property ResCountry[] $resCountries
 * @property ResCurrencyRate[] $resCurrencyRates
 */
class ResCurrency extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'res_currency';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'active', 'roundingFactor', 'symbol'], 'required'],
            [['active'], 'string'],
            [['roundingFactor'], 'number'],
            [['name'], 'string', 'max' => 64],
            [['symbol'], 'string', 'max' => 4]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'active' => 'Active',
            'roundingFactor' => 'Rounding Factor',
            'symbol' => 'Symbol',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getResCountries()
    {
        return $this->hasMany(ResCountry::className(), ['currency_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getResCurrencyRates()
    {
        return $this->hasMany(ResCurrencyRate::className(), ['currency_id' => 'id']);
    }
}
