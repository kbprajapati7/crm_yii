<?php

namespace backend\modules\base\models;

use Yii;

/**
 * This is the model class for table "res_company".
 *
 * @property integer $id
 * @property string $name
 * @property string $logo_img
 * @property string $phone
 * @property string $email
 *
 * @property ResPartner[] $resPartners
 * @property User[] $users
 */
class ResCompany extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'res_company';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'logo_img', 'phone', 'email'], 'required'],
            [['name'], 'string', 'max' => 64],
            [['logo_img', 'email'], 'string', 'max' => 100],
            [['phone'], 'string', 'max' => 13]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'logo_img' => 'Logo Img',
            'phone' => 'Phone',
            'email' => 'Email',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getResPartners()
    {
        return $this->hasMany(ResPartner::className(), ['company_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsers()
    {
        return $this->hasMany(User::className(), ['company_id' => 'id']);
    }
}
