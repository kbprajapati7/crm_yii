<?php

namespace backend\modules\base;

class Base extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\base\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
