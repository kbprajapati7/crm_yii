<?php

namespace tests\codeception\frontend\unit;

/**
 * @inheritdoc
 */
class TestCase extends \yii\codeception\TestCase
{
    public $appConfig = '@tests/codeception/config/frontend/unit.php';
}
